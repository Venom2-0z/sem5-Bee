-- DropIndex
DROP INDEX "public"."User_email_key";
