const {PrismaClient} = require( "./generated/prisma")

const prisma = new PrismaClient()

async function adduser(email,name){
  const user = await prisma.user.create({
    data:{
      email,
      name
    }
  })
  console.log(user)
}
// adduser("john.doe@example.com","John Doe")

async function readuser(email){
   return await prisma.user.findUnique({
    where:{email}
  })
}


readuser("john.doe@example.com").then(data => {
  console.log({data})
})
